# yakun_V7 使用与算法说明

版本：`yakun_V7-2026-09-14-DENSITY-GRAY-CONFIGURABLE-THRESHOLD`

本版基于本次提供的 `yakun_V6.py` 和 `yakun_V5.py`。一个独立的 `yakun_V7.py` 即可运行，不需要把 V5/V6 放在旁边，也不需要导入其他项目代码。

## 1. 本版新增功能

| 功能 | 用法 | 默认值 |
|---|---|---|
| 选择 via 边界算法 | `--edge-mode density` 或 `--edge-mode gray` | `density`，对应 V6 亮点密度算法 |
| 选择边界阈值百分比 | `--edge-threshold-percent 30` | `50`，即 50% |
| 两种算法均可额外平滑 | `--edge-smoothing auto` 或 0–100 的整数 | `auto`：density 用 20；gray 用 0 |
| 记录实际计算条件 | 表格中的 `edge_mode`、`edge_threshold_percent`，以及标注图和 settings | 自动记录 |

**适用范围：上述新模式与边缘百分比用于 `--pattern via`。** 原 V5/V6 的模式差异也集中于 via。`trench` 和 `slot` 继续使用原来的 V1.11 灰度边缘细化流程；对它们传入 `gray` 或非 50 的新参数会报错，防止把未应用的设置误当成已应用。

默认命令仍是 V6 的亮点密度 50% 路径。使用 `--edge-mode gray --edge-threshold-percent 50 --edge-smoothing 0` 可调用合入的 V5 灰度路径。默认值一致性已用合成图像对照上传的两份源代码验证；这不等于已完成真实 SEM 数据的计量准确性验证。

## 2. 安装与输入

建议使用 Python 3.10 或更新版本。在文件所在目录运行：

```powershell
python -m pip install -r requirements.txt
```

也可直接安装依赖：

```powershell
python -m pip install numpy pandas opencv-python matplotlib openpyxl
```

支持 `.jpg`、`.jpeg`、`.png`、`.tif`、`.tiff`、`.bmp`，支持中文路径。输入参数是**图片文件夹**。默认递归处理子文件夹，每次运行的文件夹应为同一种结构类型。

`--pixel-size` 必须填写图片实际标定的 **nm/像素**。例如 `0.87890625` 只是下面的示例，请换成该批图片的真实值。程序不会从示例值推断图片倍率，也不会从标尺或 TXT 自动替代此参数。

读入图片后沿用旧版预处理：彩色转灰度，以图像 1%/99% 分位数线性归一化到 0–255。因此手动 `--bright-threshold` 指的是**归一化后的灰度**。

## 3. 可直接修改使用的命令

以下都采用单行格式，适用于 PowerShell。把输入路径和像素尺寸换成自己的值。

### 3.1 V6 模式：亮点密度 50%，中心孔

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center
```

等价于明确指定：

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center --edge-mode density --edge-threshold-percent 50 --edge-smoothing 20
```

### 3.2 亮点密度 30%，中心孔

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center --edge-mode density --edge-threshold-percent 30
```

### 3.3 V5 模式：灰度 50%，中心孔

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center --edge-mode gray --edge-threshold-percent 50
```

灰度模式未指定额外平滑时，自动解析为 `--edge-smoothing 0`，保留 V5 自带的轻量半径滤波。

### 3.4 灰度 30%，中心孔

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center --edge-mode gray --edge-threshold-percent 30
```

### 3.5 全图 via，指定额外平滑及输出目录

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode all --edge-mode density --edge-threshold-percent 30 --edge-smoothing 10 --edge-relaxation 60 --output "D:\SEM\result_density30"
```

### 3.6 小数百分比

```powershell
python yakun_V7.py --input "D:\SEM\via" --pattern via --pixel-size 0.87890625 --mode center --edge-mode gray --edge-threshold-percent 32.5
```

输入 `30` 表示 30%；输入 `0.3` 表示 **0.3%**。不要输入 `30%` 字符串。

### 3.7 保留的 trench / slot 入口

```powershell
python yakun_V7.py --input "D:\SEM\trench" --pattern trench --pixel-size 0.87890625 --mode all
python yakun_V7.py --input "D:\SEM\slot" --pattern slot --pixel-size 0.87890625 --mode all
```

## 4. 全部命令行参数

| 参数 | 是否必填 / 默认 | 含义 |
|---|---|---|
| `--input` | 必填 | 输入图片文件夹 |
| `--pattern` | 必填 | `via` / `trench` / `slot` |
| `--pixel-size` | 必填 | 正数，nm/像素 |
| `--mode` | 必填 | `center` 或 `1`；`all` 或 `2` |
| `--output` | 自动生成 | 输出文件夹 |
| `--edge-mode` | `density` | via：亮点密度 `density` / 灰度 `gray` |
| `--edge-threshold-percent` | `50` | via：严格大于 0、小于 100，可为小数 |
| `--edge-relaxation` | `60` | 整数 1–100，边缘识别允许的最大放宽程度 |
| `--edge-smoothing` | `auto` | `auto` 或整数 0–100，两种 via 模式的额外角向平滑 |
| `--bright-threshold` | `auto` | density 专用：亮点判定灰度，`auto` 或 0–255 |
| `--density-radius-px` | `auto` / `0` | density 专用：局部密度窗口半径；自动或整数 1–20 像素 |
| `--max-via-cd-nm` | `80` | 正数，允许的 via 最大尺寸限制，单位 nm |
| `--via-pattern` | `auto` | 全图粗定位模型：`auto` / `via40` / `via60` |
| `--no-recursive` | 默认不启用 | 加上后只读输入文件夹第一层 |
| `--help` | — | 查看参数帮助 |

`--edge-mode` 还接受 `grayscale` / `grey` 作为 `gray` 的别名，`bright-density` / `bright_density` 作为 `density` 的别名。输出统一写成 `gray` 或 `density`。

`center` 模式先在图像中心附近 30 像素范围内寻找孔内种子，再恢复一个内圈；不是以图片中心为固定圆心画圆。`all` 模式先使用继承的 V25/V27 粗识别定位有效 via，再逐个应用选定的 V7 边界算法。`all` 不保证所有可见孔都会通过旧版定位和质量筛选。

`--edge-relaxation` 是识别约束的上限，**不是边缘阈值百分比**。程序从严格条件逐步放宽，首次成功后停止，不保证一定用到用户给定的上限。它影响对比度、有效方向比例、局部搜索范围及形状保留等条件。

在 gray 模式下，`--bright-threshold` 和 `--density-radius-px` 不参与边缘计算；显式设置非默认值时会打印提示。

## 5. 两种阈值的计算定义

设 `p = edge_threshold_percent / 100`。每个径向方向分别估计内部参考值与外部参考值，然后计算：

```text
边缘阈值 T = 内部参考值 + p × (外部参考值 − 内部参考值)
```

百分比作用于**局部内外信号差**。参考值随孔、方位及图像变化，最终不是一张图只用一个固定全局边缘阈值。输出的参考值、阈值是各径向方向对应量的中位数，因此不能保证“参考值中位数代入公式”严格等于“逐方向阈值的中位数”。

### 5.1 `gray`：V5 灰度阈值

沿径向读取灰度曲线，在窄的垂直方向带宽上平均。利用粗轮廓两侧的局部带估计孔内暗参考 `G_in` 和孔外亮参考 `G_out`，计算：

```text
T_gray = G_in + p × (G_out − G_in)
```

沿用 V5 的参考估计：内部带中位数、外部带第 75 百分位，并在必要时搜索邻近参考带、进行角向参考值处理。它并非简单取整孔平均亮度与整张图平均亮度。

例：内部灰度 40、外部灰度 180：

| 边缘百分比 | 实际灰度阈值 |
|---|---:|
| 30% | 82 |
| 50% | 110 |
| 70% | 138 |

### 5.2 `density`：V6 亮点密度阈值

先利用 `--bright-threshold` 将每个归一化灰度像素变成 0 或 1：

```text
灰度 > bright_threshold → 亮点，记作 1
灰度 ≤ bright_threshold → 暗点，记作 0
```

然后在椭圆形离散邻域核内取这些 0/1 的平均，得到 0–1 范围的局部亮点占比 `D`。核的外接尺寸为 `(2r+1) × (2r+1)`，其中 `r` 为 `density-radius-px`。自动半径沿用 V6：`round(0.032 × 最大允许孔径像素值)`，限制在 2–6 像素。

用孔内外局部密度参考 `D_in`、`D_out` 计算：

```text
T_density = D_in + p × (D_out − D_in)
```

例：内部亮点比例 0.10、外部亮点比例 0.70：

| 边缘百分比 | 实际亮点密度阈值 |
|---|---:|
| 30% | 0.28 |
| 50% | 0.40 |
| 70% | 0.52 |

所以 `--edge-threshold-percent 30` 不表示把密度固定为 0.30。`--bright-threshold 130` 也不是 130%：前者控制内外过渡的位置，后者只控制哪些像素算亮点。

### 5.3 百分比变化的影响

当孔内暗、孔外亮且过渡单调时，百分比调低通常使边缘向孔内移动，CD 变小；调高通常使边缘向外移动，CD 变大。但真实 SEM 的噪声、多重交点、局部参考带和约束可能改变跟踪路径，因此不保证每个孔的最终 CD 都严格单调。

0% 和 100% 对应参考端点，可能没有稳定的内外过渡交点，本版不接受这两个端点。接近端点的百分比虽可输入，但可能因为没有满足约束的交点而识别失败。

## 6. 边界恢复、平滑与兜底

1. 保留对应版本的粗定位与孔内种子搜索。粗分割中仍有固定参考比例，这些值用于初始化，不由本次参数统一替换。
2. 在 180 个角向方向读取曲线和两侧参考，计算用户设定的百分比阈值。
3. 寻找局部范围内由暗向亮穿越该阈值的交点，并进行亚像素插值。
4. 用圆周动态规划选择整圈连续路径，移除孤立异常点并插补允许的缺失方向。
5. gray 保留 V5 的轻量半径滤波 `0.05 / 0.90 / 0.05`；两种模式均可再加 `--edge-smoothing` 控制的圆周高斯平滑。
6. 通过稳健椭圆及径向残差限制大尺度凹陷，计算最终轮廓尺寸和面积。

`--edge-smoothing 0` 关闭的是**额外角向高斯平滑**，并未关闭动态跟踪、插补、异常点处理和形状约束。gray 仍保留上述 V5 轻量滤波。越强的平滑可能削弱局部形状并影响尺寸或圆形度。

最终轮廓含插补、滤波及形状约束，不应认为每一个最终轮廓点都精确满足原始信号的目标阈值。

为保留旧版 50% 行为，当 `edge-relaxation >= 90` 且正常跟踪失败时，50% 模式仍可能使用粗分割连通域的椭圆兜底。这类输出明确标记：

```text
edge_confidence = FORCED
edge_threshold_applied = False
edge_threshold_level = NaN
```

**非 50% 时禁止这种强制椭圆兜底**，因为它没有按用户设定的百分比寻找边界。此时若跟踪失败，会在错误表中说明原因。50% 的 FORCED 结果仍沿用旧版规则纳入统计，同时统计表提供 `n_forced`，可自行排除后重算。

`--max-via-cd-nm` 是尺寸上限约束，不会自动推断真实孔径。保留旧版部分几何检查约 1% 的容差，不能把它当作绝对不允许超过 0.01 nm 的硬截断。

## 7. 输出文件

未指定 `--output` 时，输出在输入文件夹的同级位置，例如：

```text
via_yakun_V7_density_30pct_output
via_yakun_V7_gray_50pct_output
```

不同模式或百分比默认进入不同目录。同模式、同百分比但改变其他参数时，默认目录相同，会覆盖同名结果；需要保留每轮比较结果时请指定不同的 `--output`。

| 输出 | 内容 |
|---|---|
| `yakun_V7_measurement_results.xlsx` | 全部对象、逐图统计、文件夹统计、状态、拒绝记录、错误、模型选择及参数 |
| `all_object_measurements.csv` | 每个被测结构一行 |
| `image_statistics.csv` | 每张图、每个指标的统计 |
| `folder_statistics.csv` | 所有有效对象合并统计 |
| `image_status.csv` | 各图处理状态、最终对象数及本次边缘参数 |
| `rejected_objects.csv` | 原识别核心产生的拒绝记录 |
| `processing_errors.csv` | 处理异常、图像路径及详细错误 |
| `via_model_choice.csv` | via40/via60 的粗定位模型选择信息 |
| `settings.json` | 本次运行参数和算法说明 |
| `annotated/` | 识别轮廓、对象编号、模式、百分比及计量标注 |

Excel 对应页签是 `all_objects`、`image_statistics`、`folder_statistics`、`image_status`、`rejected_objects`、`errors`、`via_model_choice`、`settings`。无记录的 CSV 可能为空文件，先查看 Excel 或状态表。

程序沿用逐图异常处理：某张图失败会记录并继续下一张。在 `all` 模式中，如果该图某个孔的最终测量抛出异常，该图本次不会写入对象结果。识别阶段未通过筛选的孔与测量阶段异常分别看拒绝表、错误表。终端出现 `Done` 只代表批处理结束，不保证每张图片都测量成功；请检查 `error_count` 和 `image_status`。

## 8. Via 主要输出字段

| 字段 | 含义 |
|---|---|
| `edge_mode` | 实际模式：`density` / `gray` |
| `edge_threshold_percent` | 用户请求的百分比，例如 30.0 |
| `edge_threshold_fraction` | 对应比例，例如 0.30 |
| `edge_threshold_applied` | 正常阈值跟踪为 True；强制粗轮廓椭圆为 False |
| `edge_status` | 本次测量状态 |
| `edge_confidence` | HIGH / MEDIUM / LOW / FORCED，主要依据放宽程度分类，不是概率置信区间 |
| `edge_reference_inside` / `edge_reference_outside` | 各方向内/外参考的中位数 |
| `edge_threshold_level` | 各方向实际信号阈值的中位数；FORCED 时为空 |
| `edge_reference_unit` | 灰度 0–255 或亮点占比 0–1 |
| `edge_cd_equivalent_nm` | 最终内圈面积对应的等效圆直径 |
| `edge_cd_x_nm` / `x_width_nm` | 最终内圈在 X 方向的投影跨度 |
| `edge_cd_y_nm` / `y_height_nm` | 最终内圈在 Y 方向的投影跨度 |
| `edge_area_nm2` / `via_inner_area_nm2` | 最终内圈面积，nm² |
| `via_width_nm` | `min(x_width_nm, y_height_nm)` |
| `via_length_nm` | `max(x_width_nm, y_height_nm)` |
| `edge_circularity` / `circularity` | 最终轮廓圆形度 `4πA/P²` |
| `edge_relaxation_requested` / `edge_relaxation_used` | 允许的最大放宽值 / 实际成功时的值 |
| `edge_smoothing_requested` | 实际解析后的额外平滑强度 |
| `edge_smoothing_applied` | 本次是否施加额外平滑；强制椭圆为 False |
| `binary_brightness_threshold_gray` | density 模式本次亮点分类使用的灰度截断值 |
| `density_window_radius_px` | density 模式实际密度窗口半径 |

尺寸计算：

```text
X跨度 = (轮廓点在 X 轴投影的最大值 − 最小值) × pixel_size_nm
Y跨度 = (轮廓点在 Y 轴投影的最大值 − 最小值) × pixel_size_nm
等效面积直径 = 2 × sqrt(内圈面积 / π)
```

**X/Y 跨度使用轮廓投影极值，不是逐行宽度平均，也不是只沿中心线测量。** `via_width_nm` / `via_length_nm` 只是 X/Y 两个方向尺寸排序，不能严格称为任意旋转椭圆的短轴/长轴。

`center` 模式的 X/Y 为图片水平/竖直方向；`all` 模式沿用阵列拟合坐标，无法可靠拟合时会回退。全图方向在粗识别时建立，最终边界测量使用该方向，不按每个孔重新寻找任意角度的主轴。

### 8.1 与 V5/V6 的字段兼容

本版统计与标注统一使用无固定百分比的 `edge_*` 字段。

- 在 50% 时，额外保留 `threshold50_cd_x_nm`、`threshold50_cd_y_nm`、`threshold50_cd_equivalent_nm` 等兼容列，数值等于对应 `edge_*`。
- 仅在 density + 50% 时，额外保留 `density50_*` 兼容列。
- 30%、70% 等其他百分比不生成这些带 `50` 的最终测量列，避免误解。
- `density_*` 诊断列只在 density 模式出现；gray 模式没有亮点二值化或密度结果。
- 旧程序若读取汇总表中的 `metric`，需要改为 `edge_cd_x_nm` / `edge_cd_y_nm` / `edge_cd_equivalent_nm` / `edge_circularity`。汇总表的指标名称会显示实际模式与百分比。
- 版本状态字符串、输出目录和工作簿名称已改成 V7；不保证旧结果每一列、每个文本值都完全相同。

统计表提供 `n`、`mean`、`std`、`median`、`min`、`max` 和 `n_forced`。`std` 为样本标准差，`ddof=1`，只有一个对象时为空。文件夹统计直接汇总所有有效对象，**不是先取每张图均值再等权平均**。

## 9. 在 Python 中调用

```python
from pathlib import Path
from yakun_V7 import main_yakun

outputs = main_yakun(
    input_dir=Path(r"D:\SEM\via"),
    pattern="via",
    pixel_size_nm=0.87890625,
    mode="center",
    output_dir=Path(r"D:\SEM\result_gray30"),
    edge_mode="gray",
    edge_threshold_percent=30.0,
    edge_smoothing=None,  # None 相当于命令行 auto；gray -> 0，density -> 20
    edge_relaxation=60,
    max_via_cd_nm=80.0,
)
print(outputs["excel"])
```

Python 接口使用 `mode="center"` / `"all"`，命令行的 `1` / `2` 别名由命令行解析器转换。

## 10. 常见问题

**如何最接近 V5 的旧结果？** 使用 `gray`、50%、平滑 0，保持同一输入、像素尺寸、center/all、识别模型、尺寸上限和放宽值。V7 的 gray 0 仍有 V5 原本的轻量滤波。

**如何最接近 V6 的旧结果？** 使用 `density`、50%，保持原亮点分类阈值、密度半径、额外平滑和其他参数；旧版未改参数时本版默认值即对应它。

**调到 30 后轮廓是否一定正确？** 百分比是计量定义，改变它会改变 CD。应结合原图、截面或机台定义评估，不能把某个百分比自动理解为真实材料边界。

**改变百分比后未识别？** 先确认单位、尺寸上限和孔的位置；再查看错误表。极端百分比可能没有满足局部范围和连续性要求的交点。放宽参数可增加允许范围，但非 50% 不会通过强制椭圆绕过阈值要求。

**为什么圆孔宽和 X 宽不一样？** `via_width_nm` 始终取 X/Y 中较小者。若 X 比 Y 大，则 `via_width_nm` 等于 Y。

**为什么代码很长，仍有旧版本函数和固定 0.5？** 为保持独立运行和旧版粗识别行为，保留了完整识别核心及历史辅助函数。新参数只传入 V7 最终 via 边缘跟踪函数；粗定位和 trench/slot 的固定比例不随本参数变化。实际入口在文件末尾 `_yakun_cli()`，无需修改顶部历史 before/after 路径。

## 11. 验证范围

本次交付使用合成图像检查参数传递与计算行为；没有收到真实 SEM 图片，因此未进行本批真实图片的标定准确性评估。

已验证：两种模式 50% 对上传旧版轮廓的逐点一致性；30%/50%/70% 的实际尺寸响应；center 与全图阵列流程；小数百分比；灰度额外平滑；非法百分比与适用范围检查；非 50% 强制椭圆兜底限制；CSV、Excel、标注 PNG、设置文件输出。具体执行结果见同包 `yakun_V7_VALIDATION.md`。
